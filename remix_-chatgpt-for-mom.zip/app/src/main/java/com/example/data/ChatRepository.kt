package com.example.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class ChatRepository(
    private val context: Context,
    private val chatDao: ChatDao
) {
    val allSessions: Flow<List<ChatSession>> = chatDao.getAllSessions()

    fun getMessagesForSession(sessionId: String): Flow<List<ChatMessage>> {
        return chatDao.getMessagesForSession(sessionId)
    }

    suspend fun createNewSession(title: String): ChatSession = withContext(Dispatchers.IO) {
        val session = ChatSession(title = title)
        chatDao.insertSession(session)
        session
    }

    suspend fun insertMessage(message: ChatMessage) = withContext(Dispatchers.IO) {
        chatDao.insertMessage(message)
    }

    suspend fun updateSessionTitle(sessionId: String, title: String) = withContext(Dispatchers.IO) {
        chatDao.updateSessionTitle(sessionId, title)
    }

    suspend fun deleteSession(sessionId: String) = withContext(Dispatchers.IO) {
        chatDao.deleteSessionWithMessages(sessionId)
    }

    /**
     * Copy visual media from content URI into the app's internal files directory.
     * Compresses the image for memory protection and optimal transfer.
     */
    suspend fun saveImageToInternalStorage(uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val contentResolver = context.contentResolver
            val inputStream = contentResolver.openInputStream(uri) ?: return@withContext null

            // First, decode bounds to check size without loading whole bitmap
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeStream(contentResolver.openInputStream(uri), null, options)

            // Let's scale down if it exceeds 1024px on any dimension to support memory economy
            val maxDim = 1024
            var scale = 1
            if (options.outHeight > maxDim || options.outWidth > maxDim) {
                scale = Math.max(options.outHeight / maxDim, options.outWidth / maxDim)
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = scale
            }

            val bitmap = BitmapFactory.decodeStream(contentResolver.openInputStream(uri), null, decodeOptions)
                ?: return@withContext null

            // Save inside a private media folder
            val mediaDir = File(context.filesDir, "media")
            if (!mediaDir.exists()) {
                mediaDir.mkdirs()
            }

            val file = File(mediaDir, "img_${UUID.randomUUID()}.jpg")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
            }

            bitmap.recycle()
            file.absolutePath
        } catch (e: Exception) {
            Log.e("ChatRepository", "Failed to save image URI: $uri", e)
            null
        }
    }

    /**
     * Converts a local JPEG file into a Base64 string for direct API transmission
     */
    private suspend fun fileToBase64(filePath: String): String? = withContext(Dispatchers.IO) {
        try {
            val file = File(filePath)
            if (!file.exists()) return@withContext null
            val bitmap = BitmapFactory.decodeFile(filePath) ?: return@withContext null
            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
            val base64 = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
            bitmap.recycle()
            base64
        } catch (e: Exception) {
            Log.e("ChatRepository", "Failed to encode image to base64: $filePath", e)
            null
        }
    }

    /**
     * Calls Gemini API with context and instructions.
     */
    suspend fun fetchGeminiResponse(
        messages: List<ChatMessage>,
        systemPrompt: String
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "API Configuration Error: Please enter your valid Gemini API Key inside the AI Studio Secrets Panel to start chatting."
        }

        try {
            // Build historical contents array
            val contentsList = mutableListOf<Content>()

            for (msg in messages) {
                val partsList = mutableListOf<Part>()
                
                // Add text first
                partsList.add(Part(text = msg.text))

                // Check if user send a photo
                if (msg.role == "user" && !msg.imagePath.isNullOrEmpty()) {
                    val base64Data = fileToBase64(msg.imagePath)
                    if (base64Data != null) {
                        partsList.add(
                            Part(
                                inlineData = InlineData(
                                    mimeType = "image/jpeg",
                                    data = base64Data
                                )
                            )
                        )
                    }
                }

                // Match API expected roles: user -> "user", model -> "model"
                val mappedRole = if (msg.role == "user") "user" else "model"
                contentsList.add(Content(role = mappedRole, parts = partsList))
            }

            // Create Request Body
            val request = GenerateContentRequest(
                contents = contentsList,
                generationConfig = GenerationConfig(
                    temperature = 0.7f
                ),
                systemInstruction = Content(
                    parts = listOf(Part(text = systemPrompt))
                )
            )

            // Make the Direct API call
            val response = RetrofitClient.service.generateContent(
                model = "gemini-3.5-flash",
                apiKey = apiKey,
                request = request
            )

            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: "I apologize, but I could not formulate a response at this moment."

        } catch (e: Exception) {
            Log.e("ChatRepository", "Gemini API call failed", e)
            "Error: Let me check. It seems like there was a connection glitch (${e.localizedMessage ?: "Unknown Error"}). Please try sending again!"
        }
    }
}
