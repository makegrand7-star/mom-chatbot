package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SleekBlue = Color(0xFF0061A4)
val SleekLightBlue = Color(0xFFD1E4FF)
val SleekUserText = Color(0xFF001D36)
val SleekBg = Color(0xFFF8F9FF)
val SleekAiBubble = Color(0xFFF2F0F4)
val SleekTextDark = Color(0xFF1B1B1F)

val EmeraldGreen = Color(0xFF10A37F)
val DarkCharcoal = Color(0xFF121214)
val WarmSlate = Color(0xFF1B1B1F)
val LightCharcoal = Color(0xFF2B2C30)
val SlateGrey = Color(0xFFE2E2E6)
val LightGreyAccent = Color(0xFFF2F0F4)
val OffWhite = Color(0xFFF8F9FF)

val Purple80 = Color(0xFF99FFD0)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF10A37F)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

