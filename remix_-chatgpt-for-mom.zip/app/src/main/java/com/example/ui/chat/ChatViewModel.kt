package com.example.ui.chat

import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.ChatMessage
import com.example.data.ChatRepository
import com.example.data.ChatSession
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ChatViewModel(private val repository: ChatRepository) : ViewModel() {

    // Dynamic state managing list of all chat sessions
    val allSessions: StateFlow<List<ChatSession>> = repository.allSessions
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _currentSessionId = MutableStateFlow<String?>(null)
    val currentSessionId: StateFlow<String?> = _currentSessionId.asStateFlow()

    // Dynamic stream loading dialogue turns of active session
    @OptIn(ExperimentalCoroutinesApi::class)
    val activeMessages: StateFlow<List<ChatMessage>> = _currentSessionId
        .flatMapLatest { sessionId ->
            if (sessionId.isNullOrEmpty()) {
                flowOf(emptyList())
            } else {
                repository.getMessagesForSession(sessionId)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Text & Image attach inputs
    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _selectedImageUri = MutableStateFlow<Uri?>(null)
    val selectedImageUri: StateFlow<Uri?> = _selectedImageUri.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    // Personalized warm persona system parameters centered purely around assisting Mom
    private val systemPrompt = """
        You are Mom's Helpful Assistant, a personalized AI buddy like ChatGPT that is specially customized to assist, support, and bring a smile to a loving mom. Always respond in a warm, patient, clear, and reassuring tone. Give practical tips, delicious easy-recipe ideas, step-by-step guidance, and hearty encouragement. Avoid overly technical jargon. Use friendly formatting (bullet points, clear paragraphs) and emojis to keep the layout eye-balanced, cheerful, and readable. If Mom attaches/sends a photo, pay close attention to it and help her describe it, suggest a recipe based on ingredients shown, or explain what things are with care and respect.
    """.trimIndent()

    fun updateInputText(text: String) {
        _inputText.value = text
    }

    fun selectImageUri(uri: Uri?) {
        _selectedImageUri.value = uri
    }

    fun selectSession(sessionId: String?) {
        _currentSessionId.value = sessionId
    }

    /**
     * Start a new, empty chat session
     */
    fun createAndSelectNewSession() {
        viewModelScope.launch {
            val defaultTitle = "New Conversation ✨"
            val newSession = repository.createNewSession(defaultTitle)
            _currentSessionId.value = newSession.id
            _inputText.value = ""
            _selectedImageUri.value = null
        }
    }

    /**
     * Send current message + optional media photo to Gemini
     */
    fun sendMessage() {
        val prompt = _inputText.value.trim()
        val attachedUri = _selectedImageUri.value
        
        if (prompt.isEmpty() && attachedUri == null) return

        // Clear input text & state immediately for reactive responsiveness
        _inputText.value = ""
        _selectedImageUri.value = null
        _isGenerating.value = true

        viewModelScope.launch {
            try {
                // Ensure there is an active session
                var sessionId = _currentSessionId.value
                var isBrandNewSession = false

                if (sessionId == null) {
                    val defaultTitle = "Conversation ✨"
                    val newSession = repository.createNewSession(defaultTitle)
                    sessionId = newSession.id
                    _currentSessionId.value = sessionId
                    isBrandNewSession = true
                }

                // If media image is attached, copy it to internal storage
                var savedImagePath: String? = null
                if (attachedUri != null) {
                    savedImagePath = repository.saveImageToInternalStorage(attachedUri)
                }

                // Save user's question locally
                val userMsg = ChatMessage(
                    sessionId = sessionId!!,
                    role = "user",
                    text = prompt.ifEmpty { "Sent an image 📷" },
                    imagePath = savedImagePath
                )
                repository.insertMessage(userMsg)

                // Retrieve all past messages in this thread as context
                val messageHistory = repository.getMessagesForSession(sessionId).first().takeLast(20)

                // Dynamic Autonaming session title based on prompt context if it's new or still default
                if (isBrandNewSession || isDefaultTitle(sessionId)) {
                    val candidateTitle = generateThreadTitle(prompt, attachedUri != null)
                    repository.updateSessionTitle(sessionId, candidateTitle)
                }

                // Call direct REST model
                val aiResponse = repository.fetchGeminiResponse(messageHistory, systemPrompt)

                // Save model's reply locally
                val modelMsg = ChatMessage(
                    sessionId = sessionId,
                    role = "model",
                    text = aiResponse
                )
                repository.insertMessage(modelMsg)

            } catch (e: Exception) {
                Log.e("ChatViewModel", "Process message transmission error", e)
            } finally {
                _isGenerating.value = false
            }
        }
    }

    private fun isDefaultTitle(sessionId: String): Boolean {
        val currentSessions = allSessions.value
        val session = currentSessions.find { it.id == sessionId }
        return session?.title == "New Conversation ✨" || session?.title == "Conversation ✨"
    }

    /**
     * Auto-generates a brief thread title based on the first prompt
     */
    private fun generateThreadTitle(prompt: String, isPhoto: Boolean): String {
        if (prompt.isEmpty() && isPhoto) return "Visual Query 📷"
        
        val cleaned = prompt.take(30).trim()
        val emoji = when {
            cleaned.contains("recipe", true) || cleaned.contains("cook", true) || cleaned.contains("food", true) -> "🍳"
            cleaned.contains("clean", true) || cleaned.contains("care", true) || cleaned.contains("tip", true) || cleaned.contains("home", true) -> "🏡"
            cleaned.contains("plan", true) || cleaned.contains("rout", true) || cleaned.contains("day", true) -> "🌸"
            cleaned.contains("sweet", true) || cleaned.contains("family", true) || cleaned.contains("msg", true) || cleaned.contains("family", true) -> "💖"
            isPhoto -> "📷"
            else -> "✨"
        }
        
        return if (cleaned.length < prompt.length) {
            "$cleaned... $emoji"
        } else {
            "$cleaned $emoji"
        }
    }

    fun deleteSession(sessionId: String) {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            if (_currentSessionId.value == sessionId) {
                _currentSessionId.value = allSessions.value.firstOrNull { it.id != sessionId }?.id
            }
        }
    }

    fun submitStarterPrompt(prompt: String) {
        _inputText.value = prompt
        sendMessage()
    }
}

class ChatViewModelFactory(private val repository: ChatRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ChatViewModel::class.java)) {
            return ChatViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
