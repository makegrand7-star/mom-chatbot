package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = SleekBlue,
    secondary = SleekLightBlue,
    tertiary = Pink80,
    background = DarkCharcoal,
    surface = WarmSlate,
    onPrimary = Color.White,
    onBackground = SlateGrey,
    onSurface = SlateGrey,
    surfaceVariant = LightCharcoal,
    onSurfaceVariant = SlateGrey
  )

private val LightColorScheme =
  lightColorScheme(
    primary = SleekBlue,
    secondary = SleekLightBlue,
    tertiary = Pink40,
    background = SleekBg,
    surface = Color.White,
    onPrimary = Color.White,
    onBackground = SleekTextDark,
    onSurface = SleekTextDark,
    surfaceVariant = SleekAiBubble,
    onSurfaceVariant = SleekTextDark
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Custom Sleek Theme is prioritized - disable dynamic override so it works on all Androids
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
